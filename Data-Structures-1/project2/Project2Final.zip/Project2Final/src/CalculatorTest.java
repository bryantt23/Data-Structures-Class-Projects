/*  Program: Calculator
    Author: Bryant Tunbutr
    Class: Data Structures
    Date: 10/15/13
    Description: Infix and Postfix Calculator

    I certify that the code below is my own work.

	Exception(s): N/A

*/


public class CalculatorTest
{
	public static void main(String[] args){
		
		System.out.println("Author:  Bryant Tunbutr");
		System.out.println();
		System.out.println();
		
		// new object	
		Calculator calc2 = new Calculator();
		
		// test cases
		
		String infix1 = "3+3";
		System.out.println("Infix: " + infix1);
		String postfix1 = calc2.infixToPostfixString(infix1);
		System.out.println("Postfix: " + postfix1);
		System.out.print("Result: " );
		calc2.postfixToOutputLong(postfix1);    		
		System.out.println();
		

		String infix2 = "(5-4)+4";
		System.out.println("Infix: " + infix2);
		String postfix2 = calc2.infixToPostfixString(infix2);
		System.out.println("Postfix: " + postfix2);
		System.out.print("Result: " );
		calc2.postfixToOutputLong(postfix1);    		
		System.out.println();

		
		String infix3 = "(2-1+4)";
		System.out.println("Infix: " + infix3);
		String postfix3 = calc2.infixToPostfixString(infix3);
		System.out.println("Postfix: " + postfix3);
		System.out.print("Result: " );
		calc2.postfixToOutputLong(postfix1);    		
		System.out.println();
		
		
		String infix4 = "((5*4/2)+(4-3+4)-(6/3))*2";
		System.out.println("Infix: " + infix4);
		String postfix4 = calc2.infixToPostfixString(infix4);
		System.out.println("Postfix: " + postfix4);
		System.out.print("Result: " );
		calc2.postfixToOutputLong(postfix1);    		
		System.out.println();
	}
}
