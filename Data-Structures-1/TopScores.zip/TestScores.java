// Keep track of top 10 scores
// Created for CSCI 220 (Fall 13)

public class TestScores
{
	public static void main(String []arg)
	{
		GameEntry p1 = new GameEntry("John", 90);
		GameEntry p2 = new GameEntry("Jane", 95);
		GameEntry p3 = new GameEntry("Bob",  60);
		GameEntry p4 = new GameEntry("Jo",   92);

		Scores top10 = new Scores();
		top10.add(p1);
		top10.add(p2);
		top10.add(p3);

		System.out.println("After 3 players were added:");
		top10.print();

		top10.add(p4);
		System.out.println("Added 4th player:");
		top10.print();


		top10.remove(0);
		System.out.println("Removed top player:");
		top10.print();


		System.out.println("Done!");
	}
}
