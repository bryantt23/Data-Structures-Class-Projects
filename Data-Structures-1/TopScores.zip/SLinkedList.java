/** Singly linked list .*/
public class SLinkedList<E> {
  protected Node<E> head;		// head node of the list
  protected long size;		// number of nodes in the list
  /** Default constructor that creates an empty list */
  public SLinkedList() {
    head = null;
    size = 0;
  }
  // ... update and search methods would go here ...
}