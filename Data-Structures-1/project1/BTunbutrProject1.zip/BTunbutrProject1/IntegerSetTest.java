
import javax.swing.*;

import java.util.*;

public class IntegerSetTest
{
	private IntegerSet setOfIntegers1, setOfIntegers2, setOfIntegers3, setOfIntegers4;
	private IntegerSet setOfIntegers7, setOfIntegers8;	
	private IntegerSet setOfIntegers9, setOfIntegers10, setOfIntegers11, setOfIntegers12;
	private IntegerSet setOfIntegers13, setOfIntegers14;
	
	private String displayString;
		
	// default constructor (empty set)
	public IntegerSetTest()
	{
		setOfIntegers1 = new IntegerSet();
		setOfIntegers2 = new IntegerSet();
		
		displayString = "";			
	}
	
	public void initialize(){
		// prompt for set 1 values
		JOptionPane.showMessageDialog(null, "Enter Set 1");

		// run method and store values
		setOfIntegers1.IntegerParameter();

		// prompt for set 2 values
		JOptionPane.showMessageDialog(null, "Enter Set 2");

		// run method and store values
		setOfIntegers2.IntegerParameter();
		
		// run method for union
		setOfIntegers3 = setOfIntegers1.union2(setOfIntegers2);
		
		// run method intersection
		setOfIntegers4 = setOfIntegers1.intersect2(setOfIntegers2);

		// create string for display
		displayString += "Test Case 1 with user input " + "\n \n" + 
		"Set 1 is made of elements :\n" + setOfIntegers1.print() +
				"\n\n Set 2 has elements: \n" + setOfIntegers2.print() +
				"\n\n The union of the 2 sets is : \n" + setOfIntegers3.print() +
				"\n\n The intersection of the 2 sets is : \n" + setOfIntegers4.print();
		
		// test if 2 sets equal
		if ( setOfIntegers1.isEqual(setOfIntegers2))
		{
			displayString += 
			"\n\n Set 1 is EQUAL to Set 2 \n";			
		}
		else
		{
			displayString += 
			"\n\n Set 1 is NOT equal to Set 2 \n";			
		}

		// test for insertion & deletion
		displayString += 
				"\n\n Inserting 66 into Set 2 \n";			
		setOfIntegers2.insertElement(66);

		displayString += 
				"\n\n Set 2 has elements \n" + setOfIntegers2.print();		
		
		displayString += 
				"\n\n Deleting 66 from Set 2 \n";			
		setOfIntegers2.removeElement(66);

		displayString += 
				"\n\n Set 2 has elements \n" + setOfIntegers2.print();		
		
		// now testing constructor
		int[] arrayInt = {23, 7, 9, 13, 45, 88, 111, 55, 129, 1};
		IntegerSet setOfIntegers5 = new IntegerSet(arrayInt);

		int[] arrayInt2 = {23, 7, 9, 55, 129, 1};
		IntegerSet setOfIntegers6 = new IntegerSet(arrayInt2);
		
		displayString +=
				"\n\n Test Case 2 with arrays \n \n" + setOfIntegers5.print() + "\n\n" + 
		setOfIntegers6.print()+ "\n\n";		

		// run method for union
		setOfIntegers7 = setOfIntegers5.union2(setOfIntegers6);
		
		// run method intersection
		setOfIntegers8 = setOfIntegers5.intersect2(setOfIntegers6);
		
		// create string for display
		displayString += "\n Set 1 is made of elements :\n" + setOfIntegers5.print() +
				"\n\n Set 2 has elements: \n" + setOfIntegers6.print() +
				"\n\n The union of the 2 sets is : \n" + setOfIntegers7.print() +
				"\n\n The intersection of the 2 sets is : \n" + setOfIntegers8.print();

		// now testing constructor
		int[] arrayInt3 = {1, 2, 4, 8, 16, 32};
		IntegerSet setOfIntegers9 = new IntegerSet(arrayInt3);

		int[] arrayInt4 = {1, 2, 4, 8, 16, 32};
		IntegerSet setOfIntegers10 = new IntegerSet(arrayInt4);
		
		displayString +=
				"\n\n Test Case 3 with same arrays \n \n" + setOfIntegers9.print() + "\n\n" + 
						setOfIntegers10.print()+ "\n\n";		
		
		// run method for union
		setOfIntegers11 = setOfIntegers9.union2(setOfIntegers10);
		
		// run method intersection
		setOfIntegers12 = setOfIntegers9.union2(setOfIntegers10);

		// create string for display
		displayString += 
				"\n\n The union of the 2 sets is : \n" + setOfIntegers11.print() +
				"\n\n The intersection of the 2 sets is : \n" + setOfIntegers12.print()+"\n\n";
		
		// test if 2 sets equal
		if ( setOfIntegers9.isEqual(setOfIntegers10))
		{
			displayString += 
			"\n\n Set 1 is EQUAL to Set 2 \n";			
		}
		else
		{
			displayString += 
			"\n\n Set 1 is NOT equal to Set 2 \n";			
		} 

		// now testing constructor
		int[] arrayInt5 = {2, 4, 8, 16, 32, 64};
		IntegerSet setOfIntegers13 = new IntegerSet(arrayInt5);

		int[] arrayInt6 = {1, 2, 4, 8, 16, 32, 64, 127};
		IntegerSet setOfIntegers14 = new IntegerSet(arrayInt6);
		
		displayString +=
				"\n\n Test Case 4 with almost same arrays \n \n" + setOfIntegers13.print() + "\n\n" + 
						setOfIntegers14.print()+ "\n\n";		
		
		// test for insertion & deletion
		displayString += 
				"\n\n Inserting 1 into Set 1 \n";			
		setOfIntegers13.insertElement(1);

		displayString += 
				"\n\n Set 1 has elements \n" + setOfIntegers13.print();		
		
		displayString += 
				"\n\n Deleting 127 from Set 2 \n";			
		setOfIntegers14.removeElement(127);
		
		displayString += 
				"\n\n Set 2 has elements \n" + setOfIntegers14.print();		

		// test if 2 sets equal
		if ( setOfIntegers13.isEqual(setOfIntegers14))
		{
			displayString += 
			"\n\n Set 1 is EQUAL to Set 2 \n";			
		}
		else
		{
			displayString += 
			"\n\n Set 1 is NOT equal to Set 2 \n";			
		}
		System.out.print(displayString);		 
	}

	public static void main(String[] args)
	{	  		
		// run application
		IntegerSetTest myProgram = new IntegerSetTest();
		myProgram.initialize();
	}
}
