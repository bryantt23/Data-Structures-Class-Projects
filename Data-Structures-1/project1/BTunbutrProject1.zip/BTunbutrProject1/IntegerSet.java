//folder/Project name: IntegerSet
//Programmer name: Bryant Tunbutr
//Date: 9/12/13
//Class name: IntegerSet
/*Project Description: This project will add, remove,
 * find the intersection, union, and whether the 
 * set is a subset of the other set
*/

import java.util.Scanner;

import javax.swing.*;

import org.omg.CORBA.PUBLIC_MEMBER;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public class IntegerSet {
    
    	// declare variables
    	boolean[] setOfIntegersArrayBool;
    	
    	// declare constants
    	final int MINIMUM_ARRAY_ELEMENT_INT = 0;
    	final int ARRAY_SIZE_INT = 128;
    	
    	// three overload constructors    	
    	// default constructor (empty set)
    	public IntegerSet()
    	{
    		// declare array of booleans (true or false, 0 or 1 that space
    		// is being held
    		setOfIntegersArrayBool = new boolean[ARRAY_SIZE_INT];    		
    	}

    	// constructor with an integer parameter (set with one integer element)
    	public void IntegerParameter()
    	{
    		// store user entered integer
    		int userEnteredElementInt;
    	      
    		// store integers from user into set
    		do {
    			// prompt user to enter integer or escape
    			userEnteredElementInt = Integer.parseInt(JOptionPane.showInputDialog(
    					"Enter an integer : " + '\n'+ "or enter -1 to escape"));

    			// check whether number is valid
    			if (isItLegalToInsertOrDeleteElement(userEnteredElementInt))
    				
    				// if valid, add to array
    				setOfIntegersArrayBool[userEnteredElementInt] = true; 		   		
    		}
    		// exit loop when -1 entered
    		while (userEnteredElementInt != -1);    	       
    	}

    	//  constructor with an integer array parameter (set with a list of elements)
    	public IntegerSet( int arrayInt[] )
    	{
    		// array of booleans
    		setOfIntegersArrayBool = new boolean[ARRAY_SIZE_INT];    		
    		
    		// run loop for length of array 
    		for(int i = 0; i < arrayInt.length; i++)
    		{    		
    			// insert element into array
    			insertElement( arrayInt[i]);    				
    		}						
    	}
    	
    	// checks whether it is legal to insert a user defined element 
    	public boolean isItLegalToInsertOrDeleteElement(int userEnteredElementInt)
    	{
    		// if it is between 0 and 127 it will return boolean of true
    		return userEnteredElementInt >= MINIMUM_ARRAY_ELEMENT_INT && userEnteredElementInt <= ARRAY_SIZE_INT;			
    	}

    	// inserts integer array (set with a list of elements) 
    	public void insertElement(int arrayIntegerToBeInsertedInt)
    	{
    		// first check to see if legal to insert integer
    		if (isItLegalToInsertOrDeleteElement(arrayIntegerToBeInsertedInt))

    			// if yes insert into array
    			setOfIntegersArrayBool[arrayIntegerToBeInsertedInt] = true; 				
    	}

    	// deletes integer from array 
    	public void removeElement(int arrayIntegerToBeDeletedInt)
    	{
    		// first check to see if legal to insert integer
    		if (isItLegalToInsertOrDeleteElement(arrayIntegerToBeDeletedInt))

    			// if yes insert into array
    			setOfIntegersArrayBool[arrayIntegerToBeDeletedInt] = false; 				
    	}

    	// prints a set as a list of elements in ascending order separated by commas 
    	public String print()
    	{
    		// what displays if array is empty
    		String arrayString = "";
    	
    		// run loop for entire potential length of array 
    		for(int i = MINIMUM_ARRAY_ELEMENT_INT; i < ARRAY_SIZE_INT; i++)
    		{
    			// if there are values in the array
    			if (setOfIntegersArrayBool[i]){
    				
    				// add each number with a comma
    				arrayString += i + ", ";    	    				
    			}   									
    		}								
			// finalize String
			arrayString = "{" + arrayString + "}";    	
			
			return arrayString; // return
    	}

    	// add elements from both sets
    	public IntegerSet union2(IntegerSet integerSet)
    	{
    		IntegerSet union2Integers = new IntegerSet();
    		    		   		
    		// run loop for entire potential length of array 
    		for(int i = MINIMUM_ARRAY_ELEMENT_INT; i < ARRAY_SIZE_INT; i++)
    			
    			// gather every element in each array
    			if (setOfIntegersArrayBool[i] || integerSet.setOfIntegersArrayBool[i])

        			// add every element in each array to union2
    				union2Integers.setOfIntegersArrayBool[i] = true;
    		
    		// return these integers
    		return union2Integers;    			
    	}

    	// return elements that are common to both sets
    	public IntegerSet intersect2(IntegerSet integerSet)
    	{
    		IntegerSet intersect2Integers = new IntegerSet();
    		    		   		
    		// run loop for entire potential length of array 
    		for(int i = MINIMUM_ARRAY_ELEMENT_INT; i < ARRAY_SIZE_INT; i++)

    			// compare every element in each array & check for inequality
    			if (setOfIntegersArrayBool[i] && integerSet.setOfIntegersArrayBool[i])        			
    				
    				// add every element in each array to intersect2
    				intersect2Integers.setOfIntegersArrayBool[i] = true;
    		
    		// return these integers
    		return intersect2Integers;     		
    	}
    	
    	// checks whether two sets are equal
    	public boolean isEqual(IntegerSet integerSet)
    	{
    		// run loop for entire potential length of array 
    		for(int i = MINIMUM_ARRAY_ELEMENT_INT; i < ARRAY_SIZE_INT; i++)
    			
    			// compare every element in each array & check for inequality
    			if (setOfIntegersArrayBool[i] != integerSet.setOfIntegersArrayBool[i])
    			
    				return false; // if not equal return false for boolean 
    		
    		return true; // sets are equal because loop has exited    		
    	}
}


