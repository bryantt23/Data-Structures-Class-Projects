import java.util.*;


/*
 * Week 1:  Use C++ STL map or Java HashMap
 * to store the following integer keys: 13 21 5 37 15
 * (use corresponding string as value so first entry would be <13, "13">). 
 * Perform various operations such as search
 * and remove to make sure it is working properly.
 */


public class Hashing {

	 public static void main( String[] args ){
		HashMap<Integer, String> hm = new HashMap<Integer, String>();
		
		hm.put(13,"13");
		hm.put(21,"21");
		hm.put(5,"5");
		hm.put(37,"37");
		hm.put(15,"15");
		
		System.out.println("size: "+ hm.size());
		System.out.println("values: " + hm.values());
		
		System.out.println("contains key 5: " + hm.containsKey(5));
		
		hm.remove(5);
		System.out.println("Remove key 5");
		System.out.println("values: " + hm.values());
		
		hm.put(7,"7");
		System.out.println("put 7");
		System.out.println(hm.values());
		
		
	 }
}
