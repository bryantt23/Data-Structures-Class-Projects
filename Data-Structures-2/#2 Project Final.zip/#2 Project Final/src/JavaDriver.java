import java.io.FileNotFoundException;
import java.io.PrintStream;

/*  Java Class: 	Sorting
    Author: 		Bryant Tunbutr
    Class: 			Data Structures II
    Date:			4/14/14
    Description:	This sorts using various algorithms

    I certify that the code below is my own work.

	Exception(s): N/A


*/

public class JavaDriver
{
	public static void main(String[] args) throws FileNotFoundException {
		
		Sorting randomly100kGenerated = new Sorting();
		
		Sorting numseq1 = new Sorting();
		Sorting numseq2 = new Sorting();
		Sorting numseq3 = new Sorting();			
		
		PrintStream ps = new PrintStream("p2Results.txt");
		PrintStream orig = System.out;
		System.setOut(ps);

		randomly100kGenerated.generateRandomArray(randomly100kGenerated.getArrayBigSize());
		randomly100kGenerated.setFile("Randomly generated array");

		System.out.println("Randomly generated array");
		System.out.println("Number of integers is " + randomly100kGenerated.getTheArray().length);
		System.out.println();
		
		randomly100kGenerated.mergeSort(randomly100kGenerated.getTheArray());
		randomly100kGenerated.bucketSort(randomly100kGenerated.getTheArray());
		
		numseq1.fileIntoArray("numseq1.dat");
		numseq1.setFile("numseq1.dat");
		
		System.out.println("File is numseq1.dat");
		System.out.println("Number of integers is " + numseq1.getArrayInt().length);
				
		numseq1.insertionSort(numseq1.getArrayInt());
		numseq1.selectionSort(numseq1.getArrayInt());
		numseq1.quickSort(numseq1.getArrayInt());
		numseq1.mergeSort(numseq1.getArrayInt());
		numseq1.bucketSort(numseq1.getArrayInt());
		

		numseq2.fileIntoArray("numseq2.dat");

		numseq2.setFile("numseq2.dat");
		
		System.out.println("File is numseq2.dat");
		System.out.println("Number of integers is " + numseq2.getArrayInt().length);		
		
//		System.out.println(Arrays.toString(arrayInt));
		numseq2.insertionSort(numseq2.getArrayInt());
		numseq2.selectionSort(numseq2.getArrayInt());
		numseq2.quickSort(numseq2.getArrayInt());
		numseq2.mergeSort(numseq2.getArrayInt());
		numseq2.bucketSort(numseq2.getArrayInt());
		
		
		numseq3.fileIntoArray("numseq3.dat");

		numseq3.setFile("numseq3.dat");
		
		System.out.println("File is numseq3.dat");
		System.out.println("Number of integers is " + numseq3.getArrayInt().length);

		numseq3.insertionSort(numseq3.getArrayInt());
		numseq3.selectionSort(numseq3.getArrayInt());
		numseq3.quickSort(numseq3.getArrayInt());
		numseq3.mergeSort(numseq3.getArrayInt());
		numseq3.bucketSort(numseq3.getArrayInt());

		System.setOut(orig);
		ps.close();
	}
}
