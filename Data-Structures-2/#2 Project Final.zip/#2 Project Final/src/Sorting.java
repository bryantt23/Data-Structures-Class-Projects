/*  Java Class: 	Sorting
    Author: 		Bryant Tunbutr
    Class: 			Data Structures II
    Date:			4/14/14
    Description:	This sorts using various algorithms

    I certify that the code below is my own work.

	Exception(s): N/A

 */

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

public class Sorting
{

	private static int arrayBigSize = 100000;

	private int[] theBigArray = new int[getArrayBigSize()];

	private int[] arrayFirstTen = new int[10];
	private int[] arrayNextTen = new int[10];
	private int[] arrayLastTen = new int[10];
	private int[] arrayNextToLast = new int[10];

	private static int[] arrayInt;

	private static int minimum;

	private int comparisons;
	private int dataMoves;

	private String file;

	// display first 20 & last 20 elements
	public void displayArrayInfo(int[] inputArray)
	{

		int tenFromLast = inputArray.length - 10;
		int twentyFromLast = inputArray.length - 20;
		int tenFromStart = 10;

		// first 10
		for (int i = 0; i < 10; i++)
		{
			arrayFirstTen[i] = inputArray[i];
		}
		// 11-20
		for (int i = 0; i < 10; i++)
		{
			arrayNextTen[i] = inputArray[tenFromStart];
			tenFromStart++;
		}

		// from last 20 until last 10
		for (int i = 0; i < 10; i++)
		{
			arrayNextToLast[i] = inputArray[twentyFromLast];
			twentyFromLast++;
		}
		// from last 10
		for (int i = 0; i < 10; i++)
		{
			arrayLastTen[i] = inputArray[tenFromLast];
			tenFromLast++;
		}

		System.out.println();
		System.out.println("First 20 sorted values ");
		System.out.println(Arrays.toString(arrayFirstTen));
		System.out.println(Arrays.toString(arrayNextTen));

		System.out.println();
		System.out.println("Last 20 sorted values ");
		System.out.println(Arrays.toString(arrayNextToLast));
		System.out.println(Arrays.toString(arrayLastTen));
	}

	// file info into array using scanner
	public void fileIntoArray(String fileName) throws FileNotFoundException
	{

		String file = fileName;

		// get file info, loop through & store as String array
		Scanner scanner1 = new Scanner(new File(file));
		setArrayInt(new int[1000]);

		int i = 0;
		while (scanner1.hasNextInt())
		{
			getArrayInt()[i++] = scanner1.nextInt();
		}
	}

	public void bucketSort2(int[] inputArray, int maxVal)
	{
		int[] bucket = new int[maxVal + 1];

		// create buckets using maximum value
		for (int i = 0; i < bucket.length; i++)
		{
			bucket[i] = 0;
		}

		// loop through array from parameter
		for (int i = 0; i < inputArray.length; i++)
		{

			// fill buckets, count elements by index
			// by incrementing by at the correct index
			bucket[inputArray[i]]++;
		}

		// buckets back into array, like concatenation
		int position = 0;
		for (int i = 0; i < bucket.length; i++)
		{
			for (int j = 0; j < bucket[i]; j++)
			{
				inputArray[position++] = i;
			}
		}
	}

	public void bucketSort(int arr[])
	{
		// start timer
		long timeStarted = System.currentTimeMillis();

		// create array
		int[] bucketSortArray = new int[arr.length];

		// copy array
		System.arraycopy(arr, 0, bucketSortArray, 0, arr.length);

		int max = bucketSortArray[0];

		for (int i = 1; i < bucketSortArray.length; i++)

			// first find maximum value
			if (bucketSortArray[i] > max)
				max = bucketSortArray[i];

		// use max value to create bucket size
		bucketSort2(bucketSortArray, max);

		// print info
		System.out.println();
		System.out.println(getFile() + " using bucket sort");
		// end timer
		System.out.println("Sorting time is "
				+ (System.currentTimeMillis() - timeStarted) + " milliseconds");

		displayArrayInfo(bucketSortArray);
		System.out.println();
	}

	// recursive merge sort
	public void mergeSort2(int array[], int lo, int hi)
	{
		int low = lo;
		int high = hi;

		if (low >= high)
		{
			comparisons++;
			return;
		}

		// find the middle index of the array
		int middle = (low + high) / 2;

		// take 1 array, create 2 arrays from it

		// merge sort of array, from 0 index to middle index of array
		mergeSort2(array, low, middle);

		// merge sort of array, from middle index + 1 to highest index of array
		mergeSort2(array, middle + 1, high);

		// last index of the first array
		int lastFirstArray = middle;

		// first index of the second array
		int startSecondArray = middle + 1;

		// while lowest index is less than or equal to first array's highest
		// index
		// AND lowest index of 2nd array less than or equal to its highest index
		while ((lo <= lastFirstArray) && (startSecondArray <= high))
		{

			comparisons++;

			// if 1st index of the 1st array is less than
			// 1st index of the 2nd array
			if (array[low] < array[startSecondArray])
			{

				// increment to the next index in the 1st array
				low++;

			} else
			{

				// store the 1st index's value into the 2nd array
				int Temp = array[startSecondArray];

				// decrement from end of first array
				for (int k = startSecondArray - 1; k >= low; k--)
				{

					array[k + 1] = array[k];
				}

				dataMoves += 3;

				array[low] = Temp;
				low++;
				lastFirstArray++;
				startSecondArray++;
			}
		}
	}

	public void mergeSort(int arr[])
	{
		// start timer
		long timeStarted = System.currentTimeMillis();

		comparisons = 0;
		dataMoves = 0;

		int[] mergeSortArray = new int[arr.length];

		System.arraycopy(arr, 0, mergeSortArray, 0, arr.length);

		mergeSort2(mergeSortArray, 0, mergeSortArray.length - 1);

		// display info including time
		System.out.println(getFile() + " using merge sort");
		System.out.println("Number of comparisons is " + comparisons);
		System.out.println("Number of data moves is " + dataMoves);
		System.out.println("Sorting time is "
				+ (System.currentTimeMillis() - timeStarted) + " milliseconds");
	}

	// partition array based on pivot provided
	public int partitionArray(int left, int right, int pivot,
			int[] quickSortArray)
	{

		int leftPointer = left - 1;

		int rightPointer = right;

		while (true)
		{

			// while left pointer is smaller than pivot
			// keep making comparisons
			while (quickSortArray[++leftPointer] < pivot)
				comparisons++;
			;

			comparisons++;
			// when reach this part, the left pointer is larger than the pivot

			// while right pointer is larger than pivot
			// keep making comparisons
			while (rightPointer > 0 && quickSortArray[--rightPointer] > pivot)
				comparisons++;
			;

			comparisons++;
			// when reach this part, the right pointer is smaller than the pivot

			// if left pointer larger than or equal to right pointer
			if (leftPointer >= rightPointer)
			{

				// start over
				break;
			} else
			{
				// swap values using function
				swapValues(leftPointer, rightPointer, quickSortArray);
			}
		}

		// swap values using function
		swapValues(leftPointer, right, quickSortArray);

		return leftPointer;
	}

	public void swapValues(int indexOne, int indexTwo, int[] quickSortArray)
	{

		// each swap counts as 3 data moves
		dataMoves += 3;

		int temp = quickSortArray[indexOne];
		quickSortArray[indexOne] = quickSortArray[indexTwo];
		quickSortArray[indexTwo] = temp;
	}

	public void quickSort2(int left, int right, int[] quickSortArray, int median)
	{

		// check if already sorted
		if (right - left <= 0)
			return;

		else
		{

			// use median as pivot
			int pivot = median;

			// // pick a pivot value
			// int pivot = quickSortArray[right];
			//
			// find pivot value based on partitioning
			int pivotLocation = partitionArray(left, right, pivot,
					quickSortArray);

			// sort left side based on pivot
			quickSort2(left, pivotLocation - 1, quickSortArray, median);

			// sort right side based on pivot
			quickSort2(pivotLocation + 1, right, quickSortArray, median);
		}
	}

	public void quickSort(int arr[])
	{
		long timeStarted = System.currentTimeMillis();

		comparisons = 0;
		dataMoves = 0;

		int[] quickSortArray = new int[arr.length];

		System.arraycopy(arr, 0, quickSortArray, 0, arr.length);

		int first, middle, last, median;

		// get first, middle, & last values of array
		first = quickSortArray[0];
		last = quickSortArray[quickSortArray.length - 1];
		middle = quickSortArray[(quickSortArray.length - 1) / 2];

		// run method to find median of first, middle, last values
		median = median(first, middle, last);

		// quickSort2(0, quickSortArray.length-1, quickSortArray);
		quickSort2(0, quickSortArray.length - 1, quickSortArray, median);

		System.out.println(getFile() + " using quick sort");
		System.out.println("Number of comparisons is " + comparisons);
		System.out.println("Number of data moves is " + dataMoves);
		System.out.println("Sorting time is "
				+ (System.currentTimeMillis() - timeStarted) + " milliseconds");
		System.out.println();
	}

	public int median(int a, int b, int c)
	{

		// a >= b and a <= c OR a <= b and a >= c
		if ((a - b) * (c - a) >= 0)
			return a;

		// b >= a and b <= c OR b <= a and b >= c
		else if ((b - a) * (c - b) >= 0)
			return b;
		else
			return c;
	}

	public void insertionSort(int arr[])
	{
		long timeStarted = System.currentTimeMillis();

		comparisons = 0;
		dataMoves = 0;

		int[] insertionSortArray = new int[arr.length];

		System.arraycopy(arr, 0, insertionSortArray, 0, arr.length);

		// loop through entire array
		for (int i = 1; i < insertionSortArray.length; i++)
		{
			int j = i;
			int toInsert = insertionSortArray[i];
			
			// sort, use while loop to sort through index 1, index 1 through 2, repeat
			while ((j > 0) && (insertionSortArray[j - 1] > toInsert))
			{
				insertionSortArray[j] = insertionSortArray[j - 1];
				j--;

				comparisons++;
				dataMoves += 3;
			}
			
			comparisons++;
			insertionSortArray[j] = toInsert;
		}
		
		System.out.println();
		System.out.println(getFile() + " using insertion sort");
		System.out.println("Number of comparisons is " + comparisons);
		System.out.println("Number of data moves is " + dataMoves);
		System.out.println("Sorting time is "
				+ (System.currentTimeMillis() - timeStarted) + " milliseconds");
		System.out.println();
	}

	public void selectionSort(int arr[])
	{
		long timeStarted = System.currentTimeMillis();

		comparisons = 0;
		dataMoves = 0;

		int[] selectionSortArray = new int[arr.length];

		System.arraycopy(arr, 0, selectionSortArray, 0, arr.length);

		for (int i = 0; i < selectionSortArray.length; i++)
		{
			// assume first element is minimum value
			minimum = i;
			
			// loop through entire array 
			for (int j = i + 1; j < selectionSortArray.length; j++)
			{
				comparisons++;
				
				// if index is less than minimum, this index is the new minimum
				if (selectionSortArray[j] < selectionSortArray[minimum])
				{
					minimum = j;
				}
			}
			
			// if current index is not equal to minimum value
			if (minimum != i)
			{
				// store current index (not minimum value) value in a temp variable
				final int temp = selectionSortArray[i];
				
				// switch current value with the minimum value
				selectionSortArray[i] = selectionSortArray[minimum];

				// switch the minimum value with the not minimum value
				selectionSortArray[minimum] = temp;
				dataMoves += 3;
			}
		}

		System.out.println(getFile() + " using selection sort");
		System.out.println("Number of comparisons is " + comparisons);
		System.out.println("Number of data moves is " + dataMoves);
		System.out.println("Sorting time is "
				+ (System.currentTimeMillis() - timeStarted) + " milliseconds");
		System.out.println();
	}

	public void generateRandomArray(int size)
	{
		for (int i = 0; i < size; i++)
		{
			getTheArray()[i] = (int) (Math.random() * size);
		}
		System.out.println();
	}

	// setters and getters
	
	public String getFile()
	{
		return file;
	}

	public void setFile(String file)
	{
		this.file = file;
	}

	public int[] getTheArray()
	{
		return theBigArray;
	}

	public void setTheArray(int[] theArray)
	{
		this.theBigArray = theArray;
	}

	public static int[] getArrayInt()
	{
		return arrayInt;
	}

	public static void setArrayInt(int[] arrayInt)
	{
		Sorting.arrayInt = arrayInt;
	}

	public static int getArrayBigSize()
	{
		return arrayBigSize;
	}

	public static void setArrayBigSize(int arrayBigSize)
	{
		Sorting.arrayBigSize = arrayBigSize;
	}
}
